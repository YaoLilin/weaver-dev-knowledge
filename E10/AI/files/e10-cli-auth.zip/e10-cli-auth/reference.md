# e10-cli 自动鉴权实现参考

在满足前置校验(测试环境地址 + 浏览器已登录)后,按下列模板执行。

## 用 ego-browser 读 ETEAMSID + auth set

以下以 `ego-browser` 为例。若改用其他浏览器能力,替换「打开页面」与「读 cookie」两步,其余逻辑不变。

```bash
export PATH="$HOME/.local/bin:$PATH"   # 若 ego-browser 不在 PATH 时
ego-browser nodejs <<'EOF'
const task = await useOrCreateTaskSpace('e10-cli鉴权')
// 1. 打开环境地址(继承登录态);wait 等待渲染
await openOrReuseTab('<环境地址>', { wait: true, timeout: 30 })
await wait(0.6)

// 2. 判断登录态
const pi = await pageInfo()
// 若 title 或 url 跳 login → 需用户在浏览器登录;登录后重跑本脚本
cliLog('page: ' + JSON.stringify({ url: pi.url, title: pi.title }))

// 3. 读 ETEAMSID(优先 CDP,可获 httpOnly)
const cs = await cdp('Network.getAllCookies', {})
const list = (cs && cs.cookies) ? cs.cookies : []
const eteams = list.filter(c => /eteamsid/i.test(c.name || ''))
const id = eteams[0] ? eteams[0].value : null
cliLog('ETEAMSID found: ' + !!id + ' len=' + (id ? id.length : 0))
if (!id) process.exit(1)

// 4. 写鉴权(值经 env 传子进程,避免明文进日志)
const nodeBin = process.env.HOME + '/.nvm/versions/node/v22.9.0/bin'  // 用 node -v 确认实际目录
const bin = nodeBin + '/e10-cli'
// 关键:子进程 PATH 需含 node 目录,否则 #!/usr/bin/env node 报 "env: node: No such file or directory"
const env = { ...process.env, PATH: nodeBin + ':' + (process.env.PATH || ''), ETEAMSID: id }
const { execSync } = await import('node:child_process')
try {
  cliLog(execSync(bin + ' auth set --eteamsid "$ETEAMSID" --base-url "<环境地址>"', { env, encoding: 'utf8' }))
} catch (e) { cliLog('set err: ' + (e.stderr || e.message)); process.exit(1) }

// 5. 验证
try {
  cliLog('status: ' + execSync(bin + ' auth status', { env, encoding: 'utf8' }))
} catch (e) { cliLog('status err: ' + (e.stderr || e.message)) }
EOF
```

## 关键点
- **PATH 修复**:`e10-cli` bin 是带 `#!/usr/bin/env node` 的脚本,子进程 `env` 必须注入 node 所在目录,否则报 `env: node: No such file or directory`。
- **ETEAMSID 脱敏**:只打印 `len` 或打码,不打印明文;值经 `ETEAMSID` 环境变量传给 CLI。
- **登录判断**:以 `pageInfo().title`/`url` 是否含 `/login` 判定,需登录时停下让用户完成登录,不要绕过。
- **浏览器技能降级**:`ego-browser` 不可用时改用 Agent 浏览器能力;仍无法控制则按 SKILL.md「失败兜底」终止。
