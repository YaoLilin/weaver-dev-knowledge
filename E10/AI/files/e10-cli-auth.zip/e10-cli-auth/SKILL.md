---
name: e10-cli-auth
description: 泛微 E10 CLI 自动鉴权技能。当用户需要执行 e10-cli auth login、e10-cli auth set、为 e10-cli 登录或完成 CLI 鉴权时使用。通过浏览器控制读取 ETEAMSID cookie 并以 e10-cli auth set 完成鉴权;要求用户提供测试环境地址、确保浏览器已完成登录,并在无法控制浏览器时终止并提示。因 OIDC 登录未实现,统一走浏览器读 cookie 方式。
---

# e10-cli 自动鉴权

## 触发时机
用户要求执行 `e10-cli auth login` / `e10-cli auth set` / 登录 CLI / 完成鉴权时使用。
说明:CLI 的 OIDC `auth login` 当前未实现,统一改为「浏览器读取 ETEAMSID cookie → `auth set`」。

## 前置校验(必须先做)
1. **环境地址**
   - 若用户未提供环境地址,先要求提供。
   - 获取地址时明确提示并只接受:**"为了安全,只能使用测试环境地址,请提供测试环境地址。"** 拿到地址后再次确认其是否为测试环境,非测试环境则拒绝并终止。
2. **CLI 是否可用**
   - 运行 `e10-cli --version`。失败则提示先安装:`npm install -g weaver-e10-builder`,安装完成再继续。

## 浏览器控制与登录
1. 优先使用本地已有浏览器控制技能(按可用性顺序):
   - `ego-browser`:创建/复用 task space,打开环境地址(默认继承用户登录态)。
   - 若上述不可用,改用当前 Agent 的浏览器能力(Browser 子代理 / webapp-testing 等)打开网址。
2. 打开环境地址后,判断是否已登录:
   - 页面跳转到 `/login` 或需登录 → **让用户在浏览器手动完成登录**,等用户确认后再继续(不得绕过)。
   - 标题含 E10/组织名、URL 为业务页 → 视为已登录,继续。
3. 无法打开/控制浏览器 → 走「失败兜底」。

## 读取 ETEAMSID 并鉴权
1. 优先用 CDP `Network.getAllCookies` 读取 cookie(可获 httpOnly),过滤器取 name 含 `ETEAMSID` 的项;取不到再尝试页面 `document.cookie`。
2. 调 `e10-cli auth set` 写入(值经环境变量传给子进程,避免明文进日志):

```bash
e10-cli auth set --eteamsid "$ETEAMSID" --base-url "<环境地址>"
```

3. 验证:

```bash
e10-cli auth status
```

确认 `userId` / `baseUrl` / `profile` 正确,即鉴权完成。

## 安全注意
- ETEAMSID 属敏感凭证:绝不在日志/回复中打印明文,经 `env` 传递给 CLI 子进程。
- 仅在用户已授权且其已登录的环境中读取 cookie。

## 失败兜底
若无法对浏览器进行控制(无浏览器技能且 Agent 浏览器能力不可用),立即终止任务,并提示用户:
**"无法完成自动鉴权,请确保当前环境具备浏览器控制能力与技能。"**

## 详细实现参考
- 完整浏览器读取 ETEAMSID + `auth set` 的代码模板见 [reference.md](reference.md)。
