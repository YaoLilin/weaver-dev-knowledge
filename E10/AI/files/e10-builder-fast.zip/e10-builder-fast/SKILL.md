---
name: e10-builder-fast
description: 泛微 E10 Ebuilder 应用快速搭建经验汇总(踩坑与加速流程)。在使用 weaver-e10-builder / e10-cli 搭建应用、表单、流程、动作流、菜单、页面时加载，减少试错与反复。涵盖出口条件正确绑定、动作流生成、JSON 解析、CLI 不支持项、浏览器页面设计器正确姿势。
---

# E10 Ebuilder 快速搭建

## 通用
- 动手前先读对应 references：`guide-workflow`(流程) / `guide-workflow-condition`(出口条件) / `guide-workflow-action`(动作流) / `guide-create-form`(表单) / `guide-list-columns`(列表列) / `guide-page-code`(页面编码)。命令坑大多在文档里。
- 先写 plan(含所有必做项)，分三段：①应用+角色+表单、②流程、③菜单+页面，每段完成后停下确认。

## 出口条件(最易错)
- `workflow condition add <wf> <sourceId> <nodeId> <名> --rule "..."`：**`sourceId` 必须是连线ID**(不是节点ID)，`nodeId`=目标节点。同源多分支必须对各条连线分别 add；对同一条线重复 add 是**替换**，别指望累加。
- 查节点/连线 ID：`workflow nodes --mode list`、`workflow link-list <wf>`。
- `save-condition` / `condition list` 回读受限(需完整上下文)，以 `condition add` 返回的独立 key 为准。

## 动作流
- 生成：`actionflow generate '{"planFile":"@绝对路径","appName":"AI-名称"}'`，`planFile` 必须 `@` 前缀；以 `component-describe <type>` 为参数权威。
- 源字段 paramKey = `<流程tableId>.<fieldId>`，从 `actionflow workflow-context-fields` 取(JSON 结构 `data[0].tableData[]`)；流程ID(请求requestId) paramKey=流程id。
- 三类：发起写台账(ApproveTrigger `triggerTiming=submitted` + `ActionEbAdd`，mapping 含 requestId→数据来源 Flow 字段)；归档更新(`workflow_completed` + `ActionEbUpdate`，opType=updateData，filterCondition 数据来源=requestId)；退回删除(`arrive`+`nodeTime:"2"`+`approveNode` + `ActionEbDelete`)。

## CLI 不支持项(勿硬啃，直接浏览器/人工)
- 明细「累加=主表」聚合校验：仅字段查重 `form validate`；`workflow node validate` 不支持 SUM，需浏览器表单保存校验或跳过。
- 页面设计器可视化组件(待办中心/导航栏/排行榜)：CLI/`@weapp/ui` 无法生成，走浏览器页面设计器，**引导用户配合**，勿全坐标自动化(拖拽易失败、点击易不命中)。
- 菜单父子层级：CLI 平铺，需浏览器菜单管理微调。

## JSON 解析
- `form read --out` 顶层是**数组**(`Array.isArray`)，字段取 `fieldId`。
- `workflow-context-fields` 结构深：`data[0].tableData[]`，字段 `paramKey/showName`。

## 浏览器页面设计器(可视化)
- 拖组件：起点用组件卡片中心，落点必须在画布/列容器内；先建「多列容器」再拖入列。
- 移除已选字段：选中 tag 右侧关闭图标(hover 显示)精确点击；不响应则重开/清空重选，不要死磕坐标。
- 每步截图确认；预留 task space 复用登录态；用户接管后再 `takeOverTaskSpace` 继续。

## 加速要点
- 先识别 CLI 不支持项，直接走浏览器/人工路径。
- 一次列全 plan 必做项，避免中途才“发现”缺配置。
- 流程/动作流固定套路：workflow create → nodes --mode list → 操作者 set-operator → link/condition(连线ID) → numbering → 节点字段赋值 save-action → actionflow generate。
