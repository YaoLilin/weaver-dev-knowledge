package com.customization.yll.liuzhoucitycollege.integration.bean;

/**
 * @author yaolilin
 * @desc 流程推送记录
 * @date 2024/12/5
 **/
public class PushRecord {
    private Integer requestId;
    private Integer processor;
    /**
     * 0:待办，1:已办，2:删除
     */
    private Integer status;

    public PushRecord() {
    }

    public PushRecord(Integer requestId, Integer processor, Integer status) {
        this.requestId = requestId;
        this.processor = processor;
        this.status = status;
    }

    public Integer getRequestId() {
        return requestId;
    }

    public void setRequestId(Integer requestId) {
        this.requestId = requestId;
    }

    public Integer getProcessor() {
        return processor;
    }

    public void setProcessor(Integer processor) {
        this.processor = processor;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
