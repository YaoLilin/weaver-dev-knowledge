package com.customization.yll.liuzhoucitycollege.config;

import com.customization.yll.common.util.PropertiesUtil;

/**
 * @author yaolilin
 * @desc 金智对接配置
 * @date 2024/12/2
 **/
public class JinzhiConfiguraton {
    public static final String FILE_NAME = "FW20241129-jinzhi";
    private static final int CACHE_EXPIRE_HALF_HOUR = 60 * 60 * 30;

    private JinzhiConfiguraton() {

    }

    public static String getAppId() {
        return PropertiesUtil.getPropValue(FILE_NAME, "appId",
                true,true, CACHE_EXPIRE_HALF_HOUR);
    }

    public static String getAppSecret() {
        return PropertiesUtil.getPropValue(FILE_NAME, "appSecret", true,
                true, CACHE_EXPIRE_HALF_HOUR);
    }

    public static String getBaseUrl() {
        return PropertiesUtil.getPropValue(FILE_NAME, "baseUrl", true,
                true, CACHE_EXPIRE_HALF_HOUR);
    }

    public static String getSceneCode() {
        return PropertiesUtil.getPropValue(FILE_NAME, "sceneCode", true,
                true, CACHE_EXPIRE_HALF_HOUR);
    }
}
