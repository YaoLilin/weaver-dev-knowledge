package com.customization.yll.liuzhoucitycollege.integration;

import com.customization.yll.liuzhoucitycollege.api.JinzhiTokenManager;
import com.wisedu.casp.sdk.api.token.TokenGatewayAccessTokenResponse;
import com.wisedu.casp.sdk.core.Client;
import com.wisedu.casp.sdk.core.DefaultTokenStore;

/**
 * @author yaolilin
 * @desc 金智接口请求自定义token存储方式
 * @date 2024/12/3
 **/
public class CustomTokenStore extends DefaultTokenStore {
    private final JinzhiTokenManager tokenManager = new JinzhiTokenManager();

    public CustomTokenStore(Client client) {
        super(client);
    }

    @Override
    protected String getTokenFromCache() {
        return tokenManager.getTokenFromCache();
    }

    @Override
    protected void setTokenCache(TokenGatewayAccessTokenResponse tokenGatewayAccessTokenResponse) {
        tokenManager.setTokenToCache(tokenGatewayAccessTokenResponse.getData());
    }
}
